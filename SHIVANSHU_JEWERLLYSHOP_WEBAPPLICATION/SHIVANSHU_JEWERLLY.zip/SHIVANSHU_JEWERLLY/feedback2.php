<html>
<style media="screen">
 a,h1{
      color:red;

    }
	
	</style></html>
<?php  
$x;
$servername="localhost";
$username="root";
$password="";
$database_name="s_jewerlyshoppe";
$conn= mysqli_connect($servername,$username,$password,$database_name);
  if(!$conn)
  {
    die("connection Failed:" .mysqli_connect_error());
  }

  if(isset($_POST['save'])) {
    function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        return $data;
     }
 
  
  

	$FEEDBACK= validate($_POST['feedback']);
	$CUSTOMERNO = validate($_POST['CUSTOMERNO']);
	if (empty($CUSTOMERNO)) {
	    exit("CUSTOMERNO NOT CLICKED");
	}else if(empty($FEEDBACK)){
	    exit("FEEDBACK  CANNOT BE EMPTY");
	} 
 
  else{
	
            $sql_query2 = "INSERT INTO feedback(CUSTOMERNO,FEEDBACK)
            VALUES('$CUSTOMERNO','$FEEDBACK')";
        
            if(mysqli_query($conn,$sql_query2))
            {
              echo "Sucessfully Placed...Session is also closed now so please relogin\n\r ";
              session_start();
            
             sleep(3);
             echo "\n<a href=index1.html>-->BACK TO HOME PAGE<--</a>";
             exit();
            }
            else {
              echo "Error: " . mysqli_error($conn);
            }
            mysqli_close($conn);
          }}
          ?>