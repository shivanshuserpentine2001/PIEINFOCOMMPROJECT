<html>
<style media="screen">
 a,u{
      color:#FA8072;;

    }
	
	</style>
<?php
session_start();
$con=mysqli_connect("localhost","root","","s_jewerlyshoppe");
if (mysqli_connect_errno())
  { echo "Failed to connect to MySQL: " . mysqli_connect_error();    }
$input=$_GET['ORDERNO'];  
$result = mysqli_query($con,"DELETE  FROM orderdata WHERE ORDERNO='$input'");
header("LOCATION:adminindex.php");
exit("DONE")
?>