<html>
<style media="screen">
 a,h1{
      color:red;

    }
	
	</style>
<?php  
session_start();
$x;
$servername="localhost";
$username="root";
$password="";
$database_name="s_jewerlyshoppe";
$conn= mysqli_connect($servername,$username,$password,$database_name);
  if(!$conn)
  {
    die("connection Failed:" .mysqli_connect_error());
  }

  if(isset($_POST['save'])) {
    function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        return $data;
     }
	$ORDERNO = validate($_POST['orderno']);
	$CUSTOMERNO = validate($_POST['CUSTOMERNO']);

	if (empty($ORDERNO)) 
	    exit("ERROR");
	else if(empty($CUSTOMERNO)){
	    exit("ERROR");}

	else{
		$sql = "SELECT STATUS FROM STATUS WHERE ORDERNO='$ORDERNO' AND CUSTOMERID='$CUSTOMERNO'";
		$result = mysqli_query($conn, $sql);
     
	}
}	
>