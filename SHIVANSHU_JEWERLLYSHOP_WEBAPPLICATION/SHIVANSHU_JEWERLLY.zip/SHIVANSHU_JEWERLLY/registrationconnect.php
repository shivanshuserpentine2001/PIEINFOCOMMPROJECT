<?php
  $servername="localhost";
  $username="root";
  $password="";
  $database_name="s_jewerlyshoppe";

  $conn= mysqli_connect($servername,$username,$password,$database_name);
  if(!$conn)
  {
    die("connection Failed:" .mysqli_connect_error());
  }
  if(isset($_POST['save']))
  {
    $FULLNAME=$_POST['FULLNAME'];
    $EMAIL=$_POST['EMAIL'];
    $MOBILENUMBER=$_POST['MOBILENO'];
    $USERID=$_POST['USERID'];
    $PASSWORD=$_POST['PASSWORD'];
  
    $sql_query = "INSERT INTO registration(FULLNAME,USERID,MOBILENO,EMAIL,PASSWORD)
    VALUES('$FULLNAME','$USERID','$MOBILENUMBER','$EMAIL','$PASSWORD')";

    if(mysqli_query($conn,$sql_query))
    {
      echo "Sucessfull";
      header("location:http://localhost/SHIVANSHU_JEWERLLY/index0.html");
    }
    else {
      echo "Error: " . mysqli_error($conn);
    }
    mysqli_close($conn);
  }
      // $conn = new mysqli("localhost","root","","test");
  // if(conn->connect_error){
  //   die('connect failed:'.$conn->connect_error);
  // }else{
  //   $stmt = $conn->prepare("insert into defaulter('name','usn','item','cost')
  //   values(?,?,?,?)");
  //   $stmt->bind_param("sssi",$name,$usn,$item,$cost);
  //   $stmt->execute();
  //   echo "registration sucessfull";
  //   $stmt->close();
  //   $conn->close();
  // }
 ?>
