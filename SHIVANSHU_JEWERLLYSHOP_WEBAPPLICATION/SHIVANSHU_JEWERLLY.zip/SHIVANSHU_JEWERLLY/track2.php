<html>
<style media="screen">
 a,h1{
      color:red;

    }
	
	</style>
<?php  
session_start();
$x;
$servername="localhost";
$username="root";
$password="";
$database_name="s_jewerlyshoppe";
$conn= mysqli_connect($servername,$username,$password,$database_name);
  if(!$conn)
  {
    die("connection Failed:" .mysqli_connect_error());
  }

  if(isset($_POST['save'])) {
    function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        return $data;
     }
	$ORDERNO = validate($_POST['orderno']);
	$CUSTOMERNO = validate($_POST['CUSTOMERNO']);

	if (empty($ORDERNO)) 
	    exit("ERROR");
	else if(empty($CUSTOMERNO)){
	    exit("ERROR");}

	else{
   
		$sql = "SELECT STATUS FROM status WHERE ORDERID='$ORDERNO' AND CUSTOMERID='$CUSTOMERNO'";
		@$result = mysqli_query($conn, $sql);
      
        @$ROW= mysqli_fetch_assoc($result);
        @$status= $ROW['STATUS'];
    }}?>    
        <html>
            <style>
                body{
                    font-family: Arial, Helvetica, sans-serif;
            background-size: cover;
            background-image: url(COURSERESOURSES.jpg);
                        background-repeat: no-repeat;
                      background-position-x: 50%;
                      
          text-decoration: none;
                }
            th{
                    border: 2px dotted black;
                    color:gold; 
                    padding:3px 3px ;
                    margin: 3px 3px; 
                }
                .t2{
                    color:green;
                }
                table{
                    padding:3px 3px ;
                    margin: 3px 3px; 
                    position:absolute;
                    left:41%;
                    top:11%;
                    border: 3px solid black;
                }
        button{
          position:absolute;
          left:1%;
          top:11%;
          border-radius:3px;
          background-color:purple;
          text-decoration:none;
          color:purple;}
          button:hover{
          background-color:#C5B4E3;
      }
      .b2{
   left:91%;
   background-color:darkred;
   height:31px;
      }
      .b2:hover{
        background-color:red;
      }
      a{
        text-decoration:none;
        color:#FA8072;
      }
            </style>
   <table>
       <tr>
           <th>STATUS OF UR PRODUCT:</th>
           <th class=t2><?PHP echo $status?></th>
       </tr>
   </table>
   <button><a href="index1.php">HOMEPAGE</a></button>
    <button class='b2'><a href="bye.php">LOGOUT</a></button>
        </html>
       
        
		
	