<html>
<?php
 session_start();
  $x;
  $servername="localhost";
  $username="root";
  $password="";
  $database_name="s_jewerlyshoppe";
  $conn= mysqli_connect($servername,$username,$password,$database_name);
    if(!$conn)
    {
      die("connection Failed:" .mysqli_connect_error());
    }
$x=$_SESSION['CUSTOMERNO'];
$sql = "SELECT ORDERNO FROM ORDERDATA WHERE CUSTOMERNO='$x'";
		$result = mysqli_query($conn, $sql); 
    if (mysqli_num_rows($result) >= 1) {
    $row = mysqli_fetch_assoc($result);
    }
  ?>
    <style>
        input{ 
            padding: 3PX 3PX;
            border: none;
            text-align: center;
        }
        table{  
          margin-top: 108px;
            text-align: center;
            padding: 11px 11px;
            position: relative;
         
        }
        body{
    background-size: cover;
    background-image: url(COURSERESOURSES.jpg);
                background-repeat: no-repeat;
                background-position-x: 50%;}

     .save{
        background: url("bb.gif");
        color: white;
        height: 31px;
              }
  
    </style>
  <center><table border="2.1px">
      <tr>
      <th>ENTER FEEDBACK</th>
      <th>ENTER CUSTOMER-NO</TH>  
    </tr>
    <TR  >
        <td rowspan="2">
        <FORM action="feeback2.php" method="POST">
        <textarea rows="4" placeholder="Enter the needful" name=feedback id=feedback>
            </textarea> </td>
        <td>
            <input type="number" placeholder="Enter Customer-number" name="CUSTOMERNO" id="CUSTOMERNO"  value="<?php echo $_SESSION['CUSTOMERNO']?>"required readonly >
        </td>
      <tr></tr><tr>
        <td colspan="2"><button type="submit" name="save" class="save" id="save">SUBMIT</button></td>
      </tr>  
        </FORM>
    </TR>
  </table>  </center>
    </html>