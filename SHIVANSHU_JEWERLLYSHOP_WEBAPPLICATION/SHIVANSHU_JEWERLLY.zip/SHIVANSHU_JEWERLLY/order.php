<html>
<style media="screen">
 a,h1{
      color:red;

    }
	
	</style></html>
<?php  
$x;
$servername="localhost";
$username="root";
$password="";
$database_name="s_jewerlyshoppe";
$conn= mysqli_connect($servername,$username,$password,$database_name);
  if(!$conn)
  {
    die("connection Failed:" .mysqli_connect_error());
  }

  if(isset($_POST['save'])) {
    function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        return $data;
     }
 
  
  

	$ORDERNO = validate($_POST['ORDERNO']);
	$CUSTOMERNO = validate($_POST['CUSTOMERNO']);
    $NETQNT=validate($_POST['NETQNT']);
    $NETVAL=validate($_POST['NETVAL']);
	if (empty($ORDERNO)) {
	    exit("ORDERNO NOT CLICKED");
	}else if(empty($CUSTOMERNO)){
	    exit("CUSTOMERNO NOT ENTERED");
	} 
  else if($NETQNT==0){
    exit("ZERO VALUE ORDER NOT ACCEPTED");
    echo "\n<a href=index1.html>-->BACK TO HOME PAGE<--</a>";
   }
  else{
	
            $sql_query2 = "INSERT INTO orderdata(ORDERNO,CUSTOMERNO,NETVAL,NETQNT)
            VALUES('$ORDERNO','$CUSTOMERNO','$NETVAL','$NETQNT')";
        
            if(mysqli_query($conn,$sql_query2))
            {
              echo "Sucessfully Placed...Session is also closed now so please relogin\n\r ";
              session_start();
              session_unset();
              session_destroy();
             sleep(3);
             echo "\n<a href=index0.html>-->BACK TO LOGIN PAGE<--</a>";
             exit();
            }
            else {
              echo "Error: " . mysqli_error($conn);
            }
            mysqli_close($conn);
          }}
          ?>