<!DOCTYPE html>
<?php session_start();?>
<html>
<style>
    BODY{
        background-image: url(COURSERESOURSES.jpg);
                background-repeat: no-repeat;
              background-position-x: 50%;
              font-family: cursive;
    }       
    .glow {
  font-size: 21px;
  color:#ECEE8C;
  text-align: center;
  animation: glow 1s ease-in-out infinite alternate;
}
.button {

  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.button4 {
    position: absolute;
    left: 55%;
  background-color: white;
  color: black;
  border: 2px solid #e7e7e7;
  width:200px;
}
.button4:hover {background-color: #e7e7e7;}
@-webkit-keyframes glow {
  from {
    text-shadow: 0 0 10px #fff, 0 0 20px #fff, 0 0 30px #e60073, 0 0 40px #e60073, 0 0 50px #e60073, 0 0 60px #e60073, 0 0 70px #e60073;
  }
}
.button42 {
    position: absolute;
    left: 33%;
  background-color: white;
  color: black;
  border: 2px solid #e7e7e7;
  width:200px;
}
.button43{
    position: absolute;
    left: 44%;
    top:70%; 
  background-color: white;
  color: black;
  border: 2px solid #e7e7e7;
  width:201px;
  background-color: TRANSPARENT; 

  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.button42:hover {background-color: #e7e7e7;}
@-webkit-keyframes glow {
  from {
    text-shadow: 0 0 10px #fff, 0 0 20px #fff, 0 0 30px #e60073, 0 0 40px #e60073, 0 0 50px #e60073, 0 0 60px #e60073, 0 0 70px #e60073;
  }
}
.button43:hover {background-color: #e7e7e7;}
@-webkit-keyframes glow {
  from {
    text-shadow: 0 0 10px #fff, 0 0 20px #fff, 0 0 30px #e60073, 0 0 40px #e60073, 0 0 50px #e60073, 0 0 60px #e60073, 0 0 70px #e60073;
  }
}
.cusinfo
{ position:fixed;
  top:81%;


}
</style>
 <head>
<title>"ONLINE JEWERLY SHOPPE"</title>
 </head>
 <body>
 <MARQUEE><h3 class="glow"> WELCOME!! FLAT 15% OFF </h3></MARQUEE>   
 <br> 

 <a href="3.php" target="_parent"><button class=" button button4">TRACK ORDER</button></a>
 <a href="index2.PHP" target="_parent"><button class=" button button42">FRESH ORDER</button></a>
 <a href="feedback.php" target="_parent"><button class=" button button43">FEEDBACK</button></a>

 <br><br>
 <br>

 <div class ="cusinfo">
  <br>
  <?php
  $info=$_SESSION['FULLNAME'];
  $info2=$_SESSION['CUSTOMERNO'];
  echo nl2br("NAME OF CUSTOMER :".$info." \n\r INCASE WRONG PLS <a href=bye.php>LOGOUT</a>");
  echo nl2br("\r\nUR CUSTOMER-NO[ID] :".$info2."");
  ?>
</div>
 </body>   
</html>
