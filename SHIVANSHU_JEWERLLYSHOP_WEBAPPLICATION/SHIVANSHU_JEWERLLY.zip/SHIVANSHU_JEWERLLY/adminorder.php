<html>
	<body >
   
	<table width="100%" height="100%" >
	  <tr height="300">
      <STYle>
      button{
          position:absolute;
          left:1%;
          top:11%;
          border-radius:3px;
          background-color:purple;
          text-decoration:none;
          color:purple;
      }
      button:hover{
        background-color:#C5B4E3;
      }
      .b2{
   left:91%;
   background-color:darkred;
   height:31px;
      }
      .b2:hover{
        background-color:red;
      }
      .b3{
   left:91%;
   top:91%;
   background-color:darkblue;
   height:31px;
      }
      .b3:hover{
        background-color:skyblue;
      }
      body
      { background-image:url("yaasqueen2.jpg");
        background-size:cover;
        
      }
      table{
          COLOR :WHITE;
          border:white;
          margin-right:41%;
          
          background-repeat:no-repeat;
      }
      a{
        text-decoration:none;
        color:#FA8072;
      }
      </STYle>
	     <td width = "100" nowrap valign="top">
	     </td>
	     <td >
<html>
    <button><a href="adminindex.php">REGISTRATION-ADMIN</a></button>
    <button class='b2'><a href="adminindex.php">LOGOUT</a></button>
    <button><a href="adminindex.php">REGISTRATION-ADMIN</a></button>
    <button class='b3'><a href="adminfeedback.php">ADMIN-FEEDBACK</a></button>
</html>    
<?php
 session_start();
$con=mysqli_connect("localhost","root","","s_jewerlyshoppe");
if (mysqli_connect_errno())
  { echo "Failed to connect to MySQL: " . mysqli_connect_error();    }
$result = mysqli_query($con,"SELECT * FROM orderdata");
echo " <center><table border='1'>
<tr>
<th>ORDER-NO</th>
<th>CUSTOMER-NO </th>
<th>NET VALUE</TH>
<th>UPDATE STATUS</th>
<th>DELETE LINK</th>
<th></th>
</tr>";
while($row = mysqli_fetch_array($result))
  { $_SESSION['ORDERNO']=$row['ORDERNO'];
    $_SESSION['CUSTOMERNO']=$row['CUSTOMERNO'];//WE can use inner join to even fetch name..etc//ALSO WE CAN USE _POST[] OR SESSION I HAVE USED POST HERE 
  echo "<tr>";
  //echo "<td>" . $row['EmpID'] . "</td>";
  echo "<td>" . $row['ORDERNO'] . "</td>";
  echo "<td>" . $row['CUSTOMERNO'] . "</td>";
  echo "<td>" . $row['NETVAL'] . "</td>";
  echo "<td><a href='updatestatus.php?ORDERNO=".$row['ORDERNO'] ."'>". 'Update' . "</a></td>";
  echo "<td><a href='deleteadminorder.php?ORDERNO=".$row['ORDERNO'] ."'>". 'Delete' . "</a></td>";
  echo "</tr>";
  }
echo "</table></center>";
mysqli_close($con);
?>
	     </td>    
	   </tr> 
    </table>		   
	</body>
</html>
