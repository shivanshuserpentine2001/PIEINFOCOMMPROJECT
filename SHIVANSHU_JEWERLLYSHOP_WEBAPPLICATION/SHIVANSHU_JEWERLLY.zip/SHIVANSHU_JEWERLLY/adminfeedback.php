<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
	<body >
	<table width="100%" height="100%" >
	  <tr height="300">
      <STYle>
      table{ position:fixed;
        left:1%;
        TOP:11%;
          COLOR :WHITE;
          border:white;
         
      }
      body
      { background-image:url("yaasqueen2.jpg");
        background-size:cover;
      }
      a{
        color:#FA8072;
      }
      </STYle>
	     <td width = "100" nowrap valign="top">
	     </td>
	     <td >
    
<?php
session_start();
$con=mysqli_connect("localhost","root","","s_jewerlyshoppe");
if (mysqli_connect_errno())
  { echo "Failed to connect to MySQL: " . mysqli_connect_error();    }
$result = mysqli_query($con,"SELECT feedback.CUSTOMERID,registration.FULLNAME,registration.EMAIL,feedback.FEEDBACK FROM `feedback` inner join registration on registration.CUSTOMERNO=FEEDBACK.CUSTOMERID");
echo " <center><table border='1'>
<tr>
<th>REGISTERED NAME</th>
<th>EMAIL</th>
<th>FEEDBACK/COMPLAINT</th>
<th>DELETE-LINK</th>
</tr>";
while($row = mysqli_fetch_array($result))
  { $_SESSION['CUSTOMERNOFORFEEDBACK']=$row['CUSTOMERID'];//we will use session here 
  echo "<tr>";
  echo "<td>" . $row['FULLNAME'] . "</td>";
  echo "<td>" . $row['EMAIL'] . "</td>";
  echo "<td>" . $row['FEEDBACK'] . "</td>";
  echo "<td><a href='deletefeedback.php?'>". 'DELETE/ACKNOWLEDGE' . "</a></td>";
  echo "</tr>";
  }
echo "</table></center>";
mysqli_close($con);
?>
	     </td>    
	   </tr> 
    </table>		   
	</body>
</html>