<html>
	<body >
   
	<table width="100%" height="100%" >
	  <tr height="300">
      <STYle>
      button{
          position:absolute;
          left:1%;
          top:11%;
          border-radius:3px;
          background-color:purple;
          text-decoration:none;
          color:purple;
      }
      body
      { background-image:url("yaasqueen2.jpg");
        background-size:cover;
        
      }
      button:hover{
        background-color:#C5B4E3;
      }
      .b2{
   left:91%;
   background-color:darkred;
   height:31px;
      }
      .b2:hover{
        background-color:red;
      }
      table{
          COLOR :WHITE;
          border:white;
          margin-right:41%;
          
          background-repeat:no-repeat;
      }
      a{
        text-decoration:none;
        color:#FA8072;
      }
      </STYle>
	     <td width = "100" nowrap valign="top">
	     </td>
	     <td >
<html>
    <button><a href="adminorder.php">ORDERSTATUS-ADMIN</a></button>
    <button class='b2'><a href="bye.php">LOGOUT</a></button>
</html>    
<?php
 session_start();
$con=mysqli_connect("localhost","root","","s_jewerlyshoppe");
if (mysqli_connect_errno())
  { echo "Failed to connect to MySQL: " . mysqli_connect_error();    }
$result = mysqli_query($con,"SELECT * FROM registration");
echo " <center><table border='1'>
<tr>
<th>CUSTOMER-NO</th>
<th>REGISTERED NAME </th>
<th>UPDATE LINK</th>
<th>DELETE LINK</th>
<th></th>
</tr>";
while($row = mysqli_fetch_array($result))
  { $_SESSION['CUSTOMER']=$row['CUSTOMERNO'];
    $_SESSION['FULLNAME']=$row['FULLNAME'];//WE CAN USE BOTH SESSION OR POST METHOD I HAVE USED SESSION 
  echo "<tr>";
  //echo "<td>" . $row['EmpID'] . "</td>";
  echo "<td>" . $row['CUSTOMERNO'] . "</td>";
  echo "<td>" . $row['FULLNAME'] . "</td>";
  echo "<td><a href='UPDATEREGISTRATION2.php?registrationno=".$row['CUSTOMERNO'] ."'>". 'Update' . "</a></td>";
  echo "<td><a href='deleteadminreg.php?registrationno=".$row['CUSTOMERNO'] ."'>". 'Delete' . "</a></td>";
  echo "</tr>";
  }
echo "</table></center>";
mysqli_close($con);
?>
	     </td>    
	   </tr> 
    </table>		   
	</body>
</html>
