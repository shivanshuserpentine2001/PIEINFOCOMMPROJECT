<html>
<style media="screen">
 a,h1{
      color:red;

    }
	
	</style>
<?php  
session_start();
$x;$z;
$servername="localhost";
$username="root";
$password="";
$database_name="s_jewerlyshoppe";
$conn= mysqli_connect($servername,$username,$password,$database_name);
  if(!$conn)
  {
    die("connection Failed:" .mysqli_connect_error());
  }

  if(isset($_POST['save'])) {
    function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        return $data;
     }
 
  
  

	$USERID = validate($_POST['uname']);
	$PASSWORD = validate($_POST['psw']);

	if (empty($USERID)) {
	    exit();
	}else if(empty($PASSWORD)){
	    exit();}
	else if($USERID=="ADMIN"&& $PASSWORD="ADMIN")
	{header("LOCATION:adminindex.php");
	}else{
		$sql = "SELECT * FROM REGISTRATION WHERE USERID='$USERID' AND PASSWORD='$PASSWORD'";
		$result = mysqli_query($conn, $sql);
		if (mysqli_num_rows($result) === 1) {
			$row = mysqli_fetch_assoc($result);
			$x=$row['FULLNAME'];
			$z=$row['CUSTOMERNO'];
			$_SESSION['CUSTOMERNO']=$z;
			$_SESSION['FULLNAME']=$x;
				    header("LOCATION:index1.php?NAME=".$x."&CUSTOMERNO=".$z."");
					}
		        
        
		else{
			echo nl2br("<h1>ERROR!!INCORRECT USERNAME OR PASSWORD COMBINATION \n NO LOGIN FOR YOU.TRY AGAIN...</h1>");
	        echo  nl2br("\n\r\n");
			echo "\n<a href=index0.html>-->BACK TO LOGIN PAGE<--</a>";
			echo  nl2br("\n\r\n");
			exit();
		}
	}
	
}else{
	exit();
}

