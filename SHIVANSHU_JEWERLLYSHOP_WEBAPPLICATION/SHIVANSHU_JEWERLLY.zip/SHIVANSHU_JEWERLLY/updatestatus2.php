<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
	<body >
	<table width="100%" height="100%" >
	  <tr width="200" height="100" >

<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$db_name="s_jewerlyshoppe"; 
$tbl_name="status"; 
$conn = mysqli_connect("$dbhost", "$dbuser", "$dbpass")or die("cannot connect"); 
mysqli_select_db($conn,"$db_name")or die("cannot select DB");
    $ORDERID=$_POST['ORDERID'];
	$STATUS=$_POST['STATUS'];
	$sql = "UPDATE STATUS SET STATUS = " ."'".$STATUS."'"." WHERE ORDERID = '$ORDERID'";
//echo $sql;
$res = mysqli_query($conn,$sql);
if($res) {
		echo "A record has been updated.";
		echo nl2br("\n");
sleep(2);
echo "\n<a href=adminindex.php>-->HOMEPAGE-ADMIN<--</a><br>";
echo nl2br("\n"); 	
echo "\n<a href=bye.PHP>-->EXIT<--</a><br>";
	} else {
		printf ("Could not update record: %s\n", mysql_error());
	}
?>
 </td>    
	   </tr>
	       </table>	  
	</body>
</html>