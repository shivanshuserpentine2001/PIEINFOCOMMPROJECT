<DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
	<body >
	<table width="100%" height="100%" >
	  <tr width="200" height="100" >

<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$db_name="s_jewerlyshoppe"; 
$tbl_name="registration"; 
$conn = mysqli_connect("$dbhost", "$dbuser", "$dbpass")or die("cannot connect"); 
mysqli_select_db($conn,"$db_name")or die("cannot select DB");
    $f=$_POST['FULLNAME'];
	$u=$_POST['USERNAME'];
    $P=$_POST['PASSWORD'];
    $cust=$_POST['CUSTOMERNO'];
	$sql = "UPDATE registration SET FULLNAME='$f' WHERE CUSTOMERNO = '$cust'";
    //$sql2 = "UPDATE registration SET USERNAME='$u' WHERE CUSTOMERNO = '$cust'";
    //$sql3 = "UPDATE registration SET PASSWORD='$P' WHERE CUSTOMERNO = '$cust'";
//echo $sql;
$res = mysqli_query($conn,$sql);
//$res2 = mysqli_query($conn,$sql2);
//$res3 = mysqli_query($conn,$sql3);
if($res) {
		echo "A record has been updated.";
		echo nl2br("\n");
sleep(2);
echo "\n<a href=adminindex.php>-->HOMEPAGE-ADMIN<--</a><br>";
echo nl2br("\n"); 	
echo "\n<a href=bye.PHP>-->EXIT<--</a><br>";
	} 
?>
 </td>    
	   </tr>
	       </table>	  
	</body>
</html>