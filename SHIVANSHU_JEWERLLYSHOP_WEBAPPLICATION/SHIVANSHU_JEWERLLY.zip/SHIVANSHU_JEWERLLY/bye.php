<?php
session_start();
session_unset();
session_destroy();
echo "\n<a href=https://www.google.com/>-->EXIT LINK<--</a>\n\r";
nl2br("\n\r");
exit("PROCESS TERMINATED EXITING SCRIPT");
echo "\n<a href=>-->BACK TO LOGIN PAGE<--</a>";
?>