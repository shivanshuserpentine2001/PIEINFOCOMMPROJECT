<html>
<style media="screen">
 a,u{
      color:#FA8072;;

    }
	
	</style>
<?php
session_start();
$con=mysqli_connect("localhost","root","","s_jewerlyshoppe");
if (mysqli_connect_errno())
  { echo "Failed to connect to MySQL: " . mysqli_connect_error();    }
$input=$_SESSION['CUSTOMER'];  
$input2=$_SESSION['FULLNAME'];  
$result = mysqli_query($con,"DELETE  FROM registration WHERE CUSTOMERNO='$input'");
echo "<h1>ADMIN THE REGISTRATION HAS BEEN SUCCCESSFULLY DELETED NAME OF CUSTOMER IS <u>".$input2."</u> all orders assoc are also deleted<h1>";
?>