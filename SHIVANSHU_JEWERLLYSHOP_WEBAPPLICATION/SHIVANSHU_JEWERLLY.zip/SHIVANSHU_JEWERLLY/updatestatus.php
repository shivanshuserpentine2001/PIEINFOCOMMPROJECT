<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
    <style>
        table{ 
            padding: 3px 3px 3px;
            margin :3px 3px;
        }
        body{
            background-color:beige;
        }
        span{
            width:auto;
        }
        </style>
	<body >
	<table width="100%" height="100%" >
	  <tr width="211" height="108" >

<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$conn = mysqli_connect($dbhost, $dbuser, $dbpass,"s_jewerlyshoppe");
if(!$conn )
{
  die('Could not connect: ' . mysql_error());
}
$registrationno = $_GET["ORDERNO"];
$registrationno = stripslashes($registrationno);
$registrationno = mysqli_real_escape_string($conn,$registrationno);
$result = mysqli_query($conn,"SELECT registration.FULLNAME,registration.EMAIL,status.ORDERID FROM status INNER JOIN registration ON registration.CUSTOMERNO = status.CUSTOMERID WHERE ORDERID='$registrationno'");
$row = mysqli_fetch_array($result)
?>
	     <td >
	     <head><h1> Update Status Order</h1></head>
<table width="300" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#CCCCCC">
<tr>
<form name="form1" method="post" action="updatestatus2.php">
  <td>
  <table width="100%" >
  <tr>
  <td width="78">FULLNAME:</td>
  <td width="6">:</td>
  <td width="294"><input name="FULLNAME" type="text" id="FULLNAME" value="<?php echo $row['FULLNAME'];?>" readonly></td>
  </tr>
   <tr>
  <tr>
  <td width="78">EMAIL:</td>
  <td width="6">:</td>
  <td width="294"><input name="EMAIL" type="text" id="EMAIL" value="<?php echo $row['EMAIL'];?>" readonly></td>
  </tr>
  <tr>
  <td width="78">ORDERID</td>
  <td width="6">:</td>
  <td width="294"><input name="ORDERID" type="text" id="ORDERID" value="<?php echo $row['ORDERID'];?>" readonly></td>
  </tr>
  <tr>
<input name="CUSTOMERNO" type="hidden" id="CUSTOMERNO" value="<?php echo $registrationno;?>"></td>
<tr><input type = "radio" name="STATUS" value="DISPACHED" id="DISPACHED"><span
          >&nbsp;DISPACHED</span>&nbsp;&nbsp;
          <input type = "radio" name="STATUS" value="REFUND" id="REFUND"><span
          >&nbsp;REFUND</span>&nbsp;&nbsp;<br><br>
          <input type = "radio" name="STATUS" value="DELIVERED" id="DELIVERED"><span
          >&nbsp;DELIVERED</span>&nbsp;&nbsp;
         
  </tr>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
  <td><input type="submit" name="Submit" value="Save"></td>
 </tr>
  </table>
  </td>
</form>
</tr>
</table>
     </td>    
	   </tr>
    </table>	    
    </body>
</html>